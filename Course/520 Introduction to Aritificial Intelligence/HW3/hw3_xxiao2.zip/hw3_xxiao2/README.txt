========= A* ==========
required prolog files: astar.pl,usroads.pl,heuristic2.pl (or heuristic.pl)
query: path(orlando, lakeCity).

========= Greedy ==========
required prolog files: greedy.pl,usroads.pl,heuristic2.pl (or heuristic.pl)
query: path(orlando, lakeCity).

========= Uniform (Branch-and-bound) ==========
required prolog files: uniform.pl,usroads.pl,heuristic2.pl (or heuristic.pl)
query: path(orlando, lakeCity).

========= Dynamic Programming ==========
required prolog files: dynamicprogramming.pl,usroads.pl,heuristic2.pl (or heuristic.pl)
query: path(orlando, lakeCity).