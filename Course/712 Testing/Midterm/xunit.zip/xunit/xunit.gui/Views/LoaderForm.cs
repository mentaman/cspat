﻿using System.Windows.Forms;

namespace Xunit.Gui
{
    public partial class LoaderForm : Form
    {
        public LoaderForm()
        {
            InitializeComponent();
        }
    }
}
