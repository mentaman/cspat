﻿using System.Reflection;

[assembly : AssemblyTitle("xUnit.net Runner for TestDriven.NET")]