﻿using System.Reflection;

[assembly : AssemblyTitle("Installer for xUnit.net")]