﻿using System.Windows.Forms;

namespace Xunit.Installer
{
    public partial class ResetDevEnvForm : Form
    {
        public ResetDevEnvForm()
        {
            InitializeComponent();
        }
    }
}
