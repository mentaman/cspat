using System;
using System.Threading;
using Microsoft.Pex.Framework;
using Xunit;
using Xunit.Extensions;

public class FreezeClockAttributeAcceptanceTests
{
    [Fact, PexMethod, FreezeClock]
    public void FrozenWithCurrentTime()
    {
        DateTime reference = DateTime.Now;

        DateTime result1 = Clock.Now;
        Thread.Sleep(100);
        DateTime result2 = Clock.Now;

        Assert.Equal(result1, result2);
        Assert.True((reference - result1).Milliseconds < 1000);
    }

    [Fact, PexMethod, FreezeClock(2006, 12, 31)]
    public void FrozenWithSpecificDate()
    {
        DateTime result = Clock.Now;

        Assert.Equal(new DateTime(2006, 12, 31), result);
    }

    [Fact, PexMethod, FreezeClock(2006, 12, 31, 4, 5, 6)]
    public void FrozenWithSpecificLocalDateTime()
    {
        DateTime result = Clock.Now;

        Assert.Equal(new DateTime(2006, 12, 31, 4, 5, 6), result);
    }

    [Fact, PexMethod, FreezeClock(2006, 12, 31, 4, 5, 6, DateTimeKind.Utc)]
    public void FrozenWithSpecificUTCDateTime()
    {
        DateTime result = Clock.Now;

        Assert.Equal(new DateTime(2006, 12, 31, 4, 5, 6, DateTimeKind.Utc).ToLocalTime(), result);
    }

    [Fact, PexMethod]
    public void NotFrozen()
    {
        DateTime result1 = Clock.Now;
        Thread.Sleep(100);
        DateTime result2 = Clock.Now;

        Assert.NotEqual(result1, result2);
    }
}