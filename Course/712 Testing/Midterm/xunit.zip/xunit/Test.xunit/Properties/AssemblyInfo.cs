using TestDriven.Framework;
using Xunit.Runner.TdNet;

[assembly: CustomTestRunner(typeof(TdNetRunner))]