using System.Reflection;
using System.Security;

[assembly : AssemblyTitle("xUnit.net")]
[assembly : AllowPartiallyTrustedCallers]