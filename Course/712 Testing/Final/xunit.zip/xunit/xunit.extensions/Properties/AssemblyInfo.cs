﻿using System.Reflection;

[assembly : AssemblyTitle("xUnit.net Extensions")]