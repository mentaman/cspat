﻿using System.Reflection;

[assembly : AssemblyTitle("xUnit.net Console Test Runner")]