﻿namespace Xunit.Gui
{
    public struct RecentlyUsedAssembly
    {
        public string AssemblyFilename { get; set; }
        public string ConfigFilename { get; set; }
    }
}