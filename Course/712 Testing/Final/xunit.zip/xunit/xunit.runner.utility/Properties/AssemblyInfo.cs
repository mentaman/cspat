﻿using System.Reflection;

[assembly: AssemblyTitle("xUnit.net Version-Independent Runner Support Library")]