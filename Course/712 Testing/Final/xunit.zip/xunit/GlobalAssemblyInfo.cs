using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("xUnit.net Testing Framework")]
[assembly: AssemblyCopyright("Copyright (C) Microsoft Corporation")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.5.0.0")]