﻿using System;
using System.IO;
using System.Linq;
using Xunit;

public class XunitProjectTests
{
    public class Load
    {
        [Fact]
        public void NullFilenameThrows()
        {
            Assert.Throws<ArgumentNullException>(() => XunitProject.Load(null));
        }

        [Fact]
        public void InvalidFilenameThrows()
        {
            Assert.Throws<FileNotFoundException>(
                () => XunitProject.Load(Guid.NewGuid().ToString()));
        }

        [Fact]
        public void IllegalXmlFileThrows()
        {
            using (TempFile tempFile = new TempFile("<invalid>"))
                Assert.Throws<ArgumentException>(() => XunitProject.Load(tempFile.Filename));
        }

        [Fact]
        public void InvalidXmlFormatThrows()
        {
            using (TempFile tempFile = new TempFile("<invalid />"))
                Assert.Throws<ArgumentException>(() => XunitProject.Load(tempFile.Filename));
        }

        [Fact]
        public void AssemblyFilenameOnly()
        {
            string xml = @"
<xunit>
    <assemblies>
        <assembly filename='C:\AssemblyFilename' />
    </assemblies>
</xunit>";

            XunitProject project;

            using (TempFile tempFile = new TempFile(xml))
                project = XunitProject.Load(tempFile.Filename);

            XunitProjectAssembly assembly = project.Assemblies.Single();
            Assert.Equal(@"C:\AssemblyFilename", assembly.AssemblyFilename);
            Assert.Null(assembly.ConfigFilename);
            Assert.True(assembly.ShadowCopy);
            Assert.Equal(0, assembly.Output.Count);
        }

        [Fact]
        public void FilenamesAreRelativeToTheProjectLocation()
        {
            string xml = @"
<xunit>
    <assemblies>
        <assembly filename='AssemblyFilename' config-filename='ConfigFilename'>
            <output type='xml' filename='XmlFilename' />
        </assembly>
    </assemblies>
</xunit>";

            XunitProject project;
            string directory;

            using (TempFile tempFile = new TempFile(xml))
            {
                directory = Path.GetDirectoryName(tempFile.Filename);
                project = XunitProject.Load(tempFile.Filename);
            }

            XunitProjectAssembly assembly = project.Assemblies.Single();
            Assert.Equal(Path.Combine(directory, "AssemblyFilename"), assembly.AssemblyFilename);
            Assert.Equal(Path.Combine(directory, "ConfigFilename"), assembly.ConfigFilename);
            Assert.Equal(Path.Combine(directory, "XmlFilename"), assembly.Output.Single().Value);
        }

        [Fact]
        public void LoadAcceptanceTest()
        {
            string xml = @"
<xunit>
    <assemblies>
        <assembly filename='C:\AssemblyFilename' config-filename='C:\ConfigFilename' shadow-copy='false'>
            <output type='xml' filename='C:\XmlFilename' />
            <output type='nunit' filename='C:\NunitFilename' />
            <output type='html' filename='C:\HtmlFilename' />
        </assembly>
        <assembly filename='C:\AssemblyFilename2' config-filename='C:\ConfigFilename2' shadow-copy='true'>
            <output type='xml' filename='C:\XmlFilename2' />
            <output type='nunit' filename='C:\NunitFilename2' />
            <output type='html' filename='C:\HtmlFilename2' />
        </assembly>
    </assemblies>
</xunit>";

            XunitProject project;

            using (TempFile tempFile = new TempFile(xml))
                project = XunitProject.Load(tempFile.Filename);

            Assert.Equal(2, project.Assemblies.Count);

            XunitProjectAssembly assembly1 = project.Assemblies[0];
            Assert.Equal(@"C:\AssemblyFilename", assembly1.AssemblyFilename);
            Assert.Equal(@"C:\ConfigFilename", assembly1.ConfigFilename);
            Assert.False(assembly1.ShadowCopy);
            Assert.Equal(3, assembly1.Output.Count);
            Assert.Equal(@"C:\XmlFilename", assembly1.Output["xml"]);
            Assert.Equal(@"C:\NunitFilename", assembly1.Output["nunit"]);
            Assert.Equal(@"C:\HtmlFilename", assembly1.Output["html"]);

            XunitProjectAssembly assembly2 = project.Assemblies[1];
            Assert.Equal(@"C:\AssemblyFilename2", assembly2.AssemblyFilename);
            Assert.Equal(@"C:\ConfigFilename2", assembly2.ConfigFilename);
            Assert.True(assembly2.ShadowCopy);
            Assert.Equal(3, assembly2.Output.Count);
            Assert.Equal(@"C:\XmlFilename2", assembly2.Output["xml"]);
            Assert.Equal(@"C:\NunitFilename2", assembly2.Output["nunit"]);
            Assert.Equal(@"C:\HtmlFilename2", assembly2.Output["html"]);
        }
    }

    public class Save
    {
        [Fact]
        public void NullFilenameThrows()
        {
            XunitProject project = new XunitProject();
            project.Assemblies.Add(new XunitProjectAssembly { AssemblyFilename = "foo" });

            Assert.Throws<ArgumentNullException>(() => project.Save(null));
        }

        [Fact]
        public void InvalidFilenameThrows()
        {
            XunitProject project = new XunitProject();
            project.Assemblies.Add(new XunitProjectAssembly { AssemblyFilename = "foo" });

            Assert.Throws<DirectoryNotFoundException>(() => project.Save(@"C:\\" + Guid.NewGuid() + "\\" + Guid.NewGuid()));
        }

        [Fact]
        public void EmptyProjectThrows()
        {
            XunitProject project = new XunitProject();

            using (TempFile tempFile = new TempFile())
                Assert.Throws<InvalidOperationException>(() => project.Save(tempFile.Filename));
        }

        [Fact]
        public void AssemblyFilenameOnly()
        {
            string expectedXml = @"<?xml version=""1.0"" encoding=""utf-8""?>
<xunit>
  <assemblies>
    <assembly filename=""C:\AssemblyFilename"" shadow-copy=""true"" />
  </assemblies>
</xunit>";

            XunitProject project = new XunitProject();
            project.Assemblies.Add(
                new XunitProjectAssembly
                {
                    AssemblyFilename = @"C:\AssemblyFilename"
                });

            using (TempFile tempFile = new TempFile())
            {
                project.Save(tempFile.Filename);

                Assert.Equal(expectedXml, File.ReadAllText(tempFile.Filename));
            }
        }

        [Fact]
        public void FilenamesAreRelativeToTheProjectLocation()
        {
            string expectedXml = @"<?xml version=""1.0"" encoding=""utf-8""?>
<xunit>
  <assemblies>
    <assembly filename=""C:\AssemblyFilename"" config-filename=""ConfigFilename"" shadow-copy=""true"" />
  </assemblies>
</xunit>";

            using (TempFile tempFile = new TempFile())
            {
                string directory = Path.GetDirectoryName(tempFile.Filename);
                XunitProject project = new XunitProject();
                project.Assemblies.Add(
                    new XunitProjectAssembly
                    {
                        AssemblyFilename = @"C:\AssemblyFilename",
                        ConfigFilename = Path.Combine(directory, "ConfigFilename")
                    });

                project.Save(tempFile.Filename);

                Assert.Equal(expectedXml, File.ReadAllText(tempFile.Filename));
            }
        }

        [Fact]
        public void SaveAcceptanceTest()
        {
            string expectedXml = @"<?xml version=""1.0"" encoding=""utf-8""?>
<xunit>
  <assemblies>
    <assembly filename=""C:\AssemblyFilename"" config-filename=""C:\ConfigFilename"" shadow-copy=""true"">
      <output type=""xml"" filename=""C:\XmlFilename"" />
      <output type=""html"" filename=""C:\HtmlFilename"" />
    </assembly>
    <assembly filename=""C:\AssemblyFilename2"" config-filename=""C:\ConfigFilename2"" shadow-copy=""false"">
      <output type=""xml"" filename=""C:\XmlFilename2"" />
      <output type=""html"" filename=""C:\HtmlFilename2"" />
    </assembly>
  </assemblies>
</xunit>";

            XunitProject project = new XunitProject();
            XunitProjectAssembly assembly1 = new XunitProjectAssembly();
            assembly1.AssemblyFilename = @"C:\AssemblyFilename";
            assembly1.ConfigFilename = @"C:\ConfigFilename";
            assembly1.ShadowCopy = true;
            assembly1.Output.Add("xml", @"C:\XmlFilename");
            assembly1.Output.Add("html", @"C:\HtmlFilename");
            project.Assemblies.Add(assembly1);
            XunitProjectAssembly assembly2 = new XunitProjectAssembly();
            assembly2.AssemblyFilename = @"C:\AssemblyFilename2";
            assembly2.ConfigFilename = @"C:\ConfigFilename2";
            assembly2.ShadowCopy = false;
            assembly2.Output.Add("xml", @"C:\XmlFilename2");
            assembly2.Output.Add("html", @"C:\HtmlFilename2");
            project.Assemblies.Add(assembly2);

            using (TempFile tempFile = new TempFile())
            {
                project.Save(tempFile.Filename);

                Assert.Equal(expectedXml, File.ReadAllText(tempFile.Filename));
            }
        }
    }

    class TempFile : IDisposable
    {
        public TempFile()
        {
            Filename = Path.GetTempFileName();
        }

        public TempFile(string contents)
            : this()
        {
            File.WriteAllText(Filename, contents);
        }

        public string Filename { get; private set; }

        public void Dispose()
        {
            File.Delete(Filename);
        }
    }
}