package parser.visitor;

public class RegisterConstant {
	public final static int AC = 0;
	public final static int AC2 = 1;
	public final static int AC3 = 2;
	public final static int AC4 = 3;
	public final static int FP = 4;
	public final static int ZERO = 5;
	public final static int SP = 6;
	public final static int PC = 7;
}
