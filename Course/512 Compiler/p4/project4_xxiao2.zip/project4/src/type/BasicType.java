package type;

public enum BasicType {
	BOOL,
	INT,
	STRING,
	ARRAY,
	VOID
}
